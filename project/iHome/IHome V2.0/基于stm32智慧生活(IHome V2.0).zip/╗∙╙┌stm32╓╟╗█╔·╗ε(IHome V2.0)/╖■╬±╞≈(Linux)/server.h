#ifndef _H_IHOMESERVER
#define _H_IHOMESERVER

#define MESIZE 2048
#define SEPERATOR 31
void * user_handler(void * arg);//deal with ever user
void service(char * rev_msg, int fd, int * userhome_flag);//
void service_management(char * operation, char * account, char * password, int fd, int * userhome_flag);
#endif // _H_IHOMESERVER
