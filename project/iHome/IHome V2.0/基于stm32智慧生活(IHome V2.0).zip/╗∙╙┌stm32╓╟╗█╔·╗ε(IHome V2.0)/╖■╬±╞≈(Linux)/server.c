#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "socket_server.h"
#include "server.h"

int user_fd = -1;
int home_fd = -1;

int main()
{
    int socket_fd;
    int user_fd;
    int pid;

    struct sockaddr_in user_addr;
    /*socket bind listen*/
    socket_fd = init_server(AF_INET, SERVER_PORT, SERVER_ADDR);
    printf("IP: %s PORT: %d\n", SERVER_ADDR, SERVER_PORT);
    while(1)
    {
        int user_len = sizeof(user_addr);
        /*wait client's requst*/
        printf("accepting the customer!\n");
        user_fd = accept(socket_fd, (struct sockaddr *)&user_addr, &user_len);
        if(user_fd == -1)
        {
            fprintf(stderr, "accept error!%s", strerror(errno));
            exit(EXIT_FAILURE);
        }
        printf("accept the request of %s  fd:%d\n", inet_ntoa(user_addr.sin_addr), user_fd);

        /*
         *  provide services for every user
         */
        if( pthread_create(&pid, NULL, (void *)user_handler, (void *)&user_fd) != 0)
        {
            printf("%s offline", inet_ntoa(user_addr.sin_addr));
            close(user_fd);
        }
    }

    return 0;
}
/*
 * funtion: service every user
 *
 */
void * user_handler(void * arg)
{
    char buff[MESIZE];
    int fd = *((int *)arg);
    int rn;
    int userhome_flag = -1; //0Ϊ�ն�,1Ϊ�ͻ�

    while(1)
    {
        memset(buff, 0, sizeof(buff));
        rn = read(fd, buff, MESIZE);
        printf("%s\n", buff);
        if(rn <= 0)
        {
            printf("%d offline\n", userhome_flag);
            if(userhome_flag == 0)
            {
                home_fd = -1;
            }
            else if(userhome_flag == 1)
            {
                user_fd = -1;
            }
            break;
        }
        else
        {
            service(buff, fd, &userhome_flag);
        }
    }
    close(fd);
}

void service(char * rev_msg, int fd, int * userhome_flag)
{
    char type[11]; // CONTRL,MESSAGE
    char source[37]; //account's num max = 36
    char destination[37]; //des's num max = 36
    char content[MESIZE];

    char tempbuf[MESIZE];

    int i;
    int j;
    int res;
    i = 0;
    /*get first field pf rev_msg is type field*/
    for(j = 0; (rev_msg[i] != SEPERATOR) && (rev_msg[i] != '\0') && j < 10; i++, j++)
    {
        type[j] = rev_msg[i];
    }
    i++;
    type[j] = '\0';
    if(strcmp(type, "MANAGE") == 0)//AUTH
    {
        char account[37]; //account's num max = 36
        char operation[37];
        char password[37];
        /*get second field pf rev_msg is account field : descript the message's account*/
        for(j = 0; (rev_msg[i] != SEPERATOR) && (rev_msg[i] != '\0') && j < 36; i++, j++)
        {
            account[j] = rev_msg[i];
        }
        i++;
        account[j] = '\0';
        /*get third field pf rev_msg is operation field : descript the message's operation*/
        for(j = 0; (rev_msg[i] != SEPERATOR) && (rev_msg[i] != '\0') && j < 36; i++, j++)
        {
            operation[j] = rev_msg[i];
        }
        i++;
        operation[j] = '\0';
        /*get forth field pf rev_msg is password field : descript the message's password*/
        for(j = 0; (rev_msg[i] != SEPERATOR) && (rev_msg[i] != '\0') && j < 36; i++, j++)
        {
            password[j] = rev_msg[i];
        }
        i++;
        password[j] = '\0';
        service_management(operation, account, password, fd, userhome_flag);
    }
    else if(strcmp(type, "CONTRL") == 0)//contrl
    {
        char account[37]; //account's num max = 36
        /*get second field pf rev_msg is account field : descript the message's account*/
        for(j = 0; (rev_msg[i] != SEPERATOR) && (rev_msg[i] != '\0') && j < 36; i++, j++)
        {
            account[j] = rev_msg[i];
        }
        i++;
        account[j] = '\0';
        /*it's user*/
        if(account[j-1] != 'h')
        {
            if(home_fd < 0)
            {
                printf("not found home!\n");
            }
            else
            {
                res = write(home_fd, rev_msg, strlen(rev_msg));
                if(res <= 0)
                {
                    fprintf(stderr, "write result error! %s %d", __FILE__, __LINE__);
                    exit(EXIT_FAILURE);
                }
            }
        }
    }
    else if(strcmp(type, "RESULT") == 0)//contrl
    {
        char account[37]; //account's num max = 36
        /*get second field pf rev_msg is account field : descript the message's account*/
        for(j = 0; (rev_msg[i] != SEPERATOR) && (rev_msg[i] != '\0') && j < 36; i++, j++)
        {
            account[j] = rev_msg[i];
        }
        i++;
        account[j] = '\0';
        /*it's home*/
        if(account[j-1]='h')
        {
            if(user_fd < 0)
            {
                printf("not found user!\n");
            }
            else
            {
                res = write(user_fd, rev_msg, strlen(rev_msg));
                if(res <= 0)
                {
                    fprintf(stderr, "write result error! %s %d", __FILE__, __LINE__);
                    exit(EXIT_FAILURE);
                }
            }
        }

    }
    else
    {
        /*get second field pf rev_msg is source field : descript the message's source*/
        for(j = 0; (rev_msg[i] != SEPERATOR) && (rev_msg[i] != '\0') && j < 36; i++, j++)
        {
            source[j] = rev_msg[i];
        }
        i++;
        source[j] = '\0';
        /*get third field pf rev_msg is destination field : descript the message's destination*/
        for(j = 0; (rev_msg[i] != SEPERATOR) && (rev_msg[i] != '\0') && j < 36; i++, j++)
        {
            destination[j] = rev_msg[i];
        }
        i++;
        destination[j] = '\0';
        /*get forth field pf rev_msg is content field : descript the message's content*/
        for(j = 0; (rev_msg[i] != SEPERATOR) && (rev_msg[i] != '\0'); i++, j++)
        {
            content[j] = rev_msg[i];
        }
        i++;
        content[j] = '\0';
        printf("%s %s %s %s\n", type, source, destination, content);
    }
}

void service_management(char * operation, char * account, char * password, int fd, int * userhome_flag)
{
    int res;
    char tempbuf[MESIZE];

    if(strcmp(operation, "LOGIN") == 0)
    {
        if(strcmp(account, "975559549") == 0)
        {

            if(strcmp(password, "545538516") == 0)
            {
                user_fd = fd; //��¼�û�fd
                *userhome_flag = 1;
                sprintf(tempbuf, "RESULT%cLOGIN%cSUCCESS%c", SEPERATOR, SEPERATOR, SEPERATOR);
                res = write(fd, tempbuf, strlen(tempbuf));
                if(res <= 0)
                {
                    fprintf(stderr, "write result error! %s %d", __FILE__, __LINE__);
                    exit(EXIT_FAILURE);
                }
    	        printf("975559549 user login success!\n");

            }
            else
            {
                sprintf(tempbuf, "RESULT%cLOGIN%cFAILED%c%c", SEPERATOR, SEPERATOR, SEPERATOR, SEPERATOR);
                res = write(fd, tempbuf, strlen(tempbuf));
                if(res <= 0)
                {
                    fprintf(stderr, "write result error! %s %d", __FILE__, __LINE__);
                    exit(EXIT_FAILURE);
                }
                printf("975559549 user login falied!\n");
            }
        }
        else if(strcmp(account, "975559549h") == 0)
        {

            if(strcmp(password, "975559549") == 0)
            {
                home_fd = fd; //��¼��ͥfd
                *userhome_flag = 0;
                sprintf(tempbuf, "RESULT%cLOGIN%cSUCCESS%c%c", SEPERATOR, SEPERATOR, SEPERATOR, SEPERATOR);
                res = write(fd, tempbuf, strlen(tempbuf));
                if(res <= 0)
                {
                    fprintf(stderr, "write result error! %s %d", __FILE__, __LINE__);
                    exit(EXIT_FAILURE);
                }
    	        printf("975559549 home login success!\n");

            }
            else
            {
                sprintf(tempbuf, "RESULT%cLOGIN%cFAILED%c%c", SEPERATOR, SEPERATOR, SEPERATOR, SEPERATOR);
                res = write(fd, tempbuf, strlen(tempbuf));
                if(res <= 0)
                {
                    fprintf(stderr, "write result error! %s %d", __FILE__, __LINE__);
                    exit(EXIT_FAILURE);
                }
                printf("975559549 home login failed!\n");
            }
        }
        else
        {
            sprintf(tempbuf, "RESULT%cLOGIN%cFAILED%c%c", SEPERATOR, SEPERATOR, SEPERATOR, SEPERATOR);
            res = write(fd, tempbuf, strlen(tempbuf));
            if(res <= 0)
            {
                fprintf(stderr, "write result error! %s %d", __FILE__, __LINE__);
                exit(EXIT_FAILURE);
            }
            printf("%s login falied!\n", account);

        }
    }
}

