package ihome_client.bottombar;

public class Constant {  
    //Btn�ı�ʶ  
    public static final int BTN_FLAG_IHOME = 0x01;  
    public static final int BTN_FLAG_CONTRL = 0x01 << 1;  
    public static final int BTN_FLAG_VIDEO = 0x01 << 2;  
    public static final int BTN_FLAG_CSERVICE = 0x01 << 3;  
      
    //Fragment�ı�ʶ  
    public static final String FRAGMENT_FLAG_IHOME = "IHome";   
    public static final String FRAGMENT_FLAG_CONTRL = "ң��";   
    public static final String FRAGMENT_FLAG_VIDEO = "��Ƶ";   
    public static final String FRAGMENT_FLAG_CSERVICE = "�ͷ�";   
    public static final String FRAGMENT_FLAG_SIMPLE = "simple";   
      
      
}  
