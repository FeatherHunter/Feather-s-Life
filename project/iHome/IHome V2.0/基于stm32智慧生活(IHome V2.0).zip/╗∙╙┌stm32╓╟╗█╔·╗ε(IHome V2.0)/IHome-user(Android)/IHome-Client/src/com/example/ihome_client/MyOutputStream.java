package com.example.ihome_client;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;

public class MyOutputStream extends OutputStream implements Serializable{

	@Override
	public void write(int oneByte) throws IOException {
		// TODO Auto-generated method stub
	}

}
