package com.example.ihome_client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;

public class MyInputStream extends InputStream implements Serializable{

	@Override
	public int read() throws IOException {
		// TODO Auto-generated method stub
		return 0;
	}

}
