package com.example.ihome_client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.net.UnknownHostException;

import com.feather.socketservice.IHomeService;

import ihome_client.bottombar.BottomBarPanel;
import ihome_client.bottombar.BottomBarPanel;
import ihome_client.bottombar.Constant;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.R.integer;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.location.GpsStatus.Listener;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import ihome_client.*;

public class ClientActivity extends Activity {

	private ImageView logoImageView;
	private EditText client_account, client_password;
	private Button client_login, client_bluetooth;
	private BottomBarPanel bottomBarPanel;
	
	private String accountString;     //�˻�
	private String passwordString;    //����
	private Boolean isAuthed = false;
	private String AUTH_ACTION = "android.intent.action.ANSWER";
	
	private Handler handler = new Handler();
	private AuthReceiver authReceiver;//�㲥������
	private ProgressDialog dialog; //��¼�Ľ�����
	private boolean firstSwitch = true;//��һ��ת����ClientMainActivity������Ҫˢ�½���
	
	private Intent serviceIntent; //����Intent
	
	//IHomeService.ServiceBinder serviceBinder;//IHomeService�е�binder
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client);  	
		
        logoImageView = (ImageView) findViewById(R.id.ihome_logo);
        client_account = (EditText) findViewById(R.id.client_account);
        client_password = (EditText) findViewById(R.id.client_password);
        client_login = (Button) findViewById(R.id.client_login);
        client_bluetooth = (Button) findViewById(R.id.client_bluetooth);
        client_login.setOnClickListener(new LoginButtonListener());
        client_bluetooth.setOnClickListener(new BluetoothButtonListener());
        
        /* connect server */
		dialog = new ProgressDialog(this);
		dialog.setTitle("��ʾ");
		dialog.setMessage("���ڵ�¼��...");
		dialog.setCancelable(false);
        
    }
    class LoginButtonListener implements OnClickListener
    {

    	public void onClick(View v) {
    		// TODO Auto-generated method stub
    		accountString = client_account.getText().toString();
    		passwordString = client_password.getText().toString();
    		
    		/*��̬ע��receiver*/
    		authReceiver = new AuthReceiver();
    		IntentFilter filter = new IntentFilter();
    		filter.addAction(AUTH_ACTION);
    		registerReceiver(authReceiver, filter);//ע��
    		
    		/*��service, ����connection������service����ϵ*/
    		serviceIntent = new Intent();
    		serviceIntent.putExtra("command", "auth");
    		serviceIntent.putExtra("account", "975559549");
    		serviceIntent.putExtra("password", "545538516");
    		serviceIntent.setClass(ClientActivity.this, IHomeService.class);
    		//bindService(serviceIntent, connection, BIND_AUTO_CREATE); //��service,�����Զ�����service
    		startService(serviceIntent); //��������
    		dialog.show(); //��ʾ��½������
    		/*��ʱ����*/
    		Thread thread = new Thread(loginOvertimeRunnable);
    		thread.start();
    	}	
    }
    
    class BluetoothButtonListener implements OnClickListener
    {

    	public void onClick(View v) {
    		Intent intent = new Intent();
			
			intent.putExtra("mode", 2);//ѡ��ģʽ��2Ϊ����ģʽ
    		intent.putExtra("account", client_account.getText().toString());
            intent.setClass(ClientActivity.this, ClientMainActivity.class);
            ClientActivity.this.startActivity(intent);
    	}	
    }
    /*����10S��û�����ӳɹ�����һ��ʧ����*/
    Runnable loginOvertimeRunnable = new Runnable() {
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(isAuthed == false)
			{
				dialog.dismiss();
				handler.post(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						Toast.makeText(ClientActivity.this, "��½��ʱ", Toast.LENGTH_SHORT).show();
						
			    		serviceIntent = new Intent();
			    		serviceIntent.putExtra("command", "stop");
			    		serviceIntent.setClass(ClientActivity.this, IHomeService.class);
			    		startService(serviceIntent); //����ָֹͣ��
			    		stopService(serviceIntent);  //�رպ�̨���ӷ���
					}
				});
			}
			
		}
	};
//    /*����service��activity֮��ͨ�ţ�ֱ�ӵ���IHomeService֮��ServiceBinder�ķ�������serviceͨ��*/
//    private ServiceConnection connection = new ServiceConnection() {
//		
//		@Override
//		public void onServiceDisconnected(ComponentName name) {
//			// TODO Auto-generated method stub
//			
//		}
//		
//		@Override
//		public void onServiceConnected(ComponentName name, IBinder service) {
//			// TODO Auto-generated method stub
//			serviceBinder = (ServiceBinder) service;
//			//serviceBinder.auth(accountString, passwordString);
//			
//		}
//		
//	};
	
	private class AuthReceiver extends BroadcastReceiver{

		public AuthReceiver() {
			// TODO Auto-generated constructor stub
		}
		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			if(firstSwitch == true)
			{
				firstSwitch = false;
				String resultString = intent.getStringExtra("result");
				if(resultString.equals("success"))
				{
					/*�л������ؽ���*/
		    		Intent intentMain = new Intent();
					
		    		intentMain.putExtra("mode", 1);//ѡ��ģʽ��1Ϊethnetģʽ
		    		intentMain.putExtra("account", client_account.getText().toString());
		    		intentMain.setClass(ClientActivity.this, ClientMainActivity.class);
		            ClientActivity.this.startActivity(intentMain);
		            
					isAuthed = true;
					
					dialog.dismiss(); //��½�ɹ������������
				}
				else if (resultString.equals("falied")) {
					Toast.makeText(ClientActivity.this, "��½ʧ�ܣ�", Toast.LENGTH_SHORT).show();
					/*�������*/
					client_account.setText("");
					client_password.setText("");
					isAuthed = false;
					dialog.dismiss(); //��½ʧ�ܣ����������
				}
			}
		}
		
		
	}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    	menu.add(0, 0, 0, "�˳�");
    	menu.add(1, 1, 1, "����");
    	menu.add(2, 2, 2, "����");
        //getMenuInflater().inflate(R.menu.client, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 0) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		unregisterReceiver(authReceiver); //���receiver��ע��
		/*ֹͣ��̨����*/
		Intent serviceIntent = new Intent();
		serviceIntent.setClass(ClientActivity.this, IHomeService.class);
		stopService(serviceIntent);
		//unbindService(connection);//�����
	}
    
    
    
}


